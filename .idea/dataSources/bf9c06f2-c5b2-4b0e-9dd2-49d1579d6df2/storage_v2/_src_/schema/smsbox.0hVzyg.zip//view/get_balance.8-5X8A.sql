create view get_balance as
  select
    `get_account`.`userID`       AS `userID`,
    sum(`get_account`.`balance`) AS `bal`
  from `smsbox`.`get_account`
  group by `get_account`.`userID`;

