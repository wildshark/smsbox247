create view get_message as
  select
    `smsbox`.`message`.`smsID`    AS `smsID`,
    `smsbox`.`message`.`userID`   AS `userID`,
    `smsbox`.`message`.`tran_due` AS `tran_due`,
    `smsbox`.`message`.`s_date`   AS `s_date`,
    `smsbox`.`message`.`sms_to`   AS `sms_to`,
    `smsbox`.`message`.`sms_msg`  AS `sms_msg`,
    `smsbox`.`message`.`statusID` AS `statusID`
  from `smsbox`.`message`
  where (`smsbox`.`message`.`statusID` = 1)
  order by `smsbox`.`message`.`smsID` desc;

