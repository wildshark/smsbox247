create view get_user_account as
  select
    `smsbox`.`user_account`.`date_created` AS `date_created`,
    `smsbox`.`user_account`.`full_name`    AS `full_name`,
    `smsbox`.`user_account`.`username`     AS `username`,
    `smsbox`.`user_account`.`passwd`       AS `passwd`,
    `smsbox`.`user_account`.`mobile`       AS `mobile`,
    `smsbox`.`user_account`.`email`        AS `email`,
    `smsbox`.`user_account`.`api_key`      AS `api_key`,
    `smsbox`.`user_account`.`credit`       AS `credit`,
    `smsbox`.`user_account`.`statusID`     AS `statusID`,
    `smsbox`.`user_account`.`userID`       AS `userID`,
    `smsbox`.`user_account`.`photo`        AS `photo`
  from `smsbox`.`user_account`;

