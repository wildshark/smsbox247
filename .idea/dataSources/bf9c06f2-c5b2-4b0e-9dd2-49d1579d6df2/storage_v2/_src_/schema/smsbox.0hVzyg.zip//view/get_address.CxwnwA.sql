create view get_address as
  select `smsbox`.`address`.`addressID` AS `addressID`,
         `smsbox`.`address`.`name`      AS `name`,
         `smsbox`.`address`.`email`     AS `email`,
         `smsbox`.`address`.`mobile1`   AS `mobile1`,
         `smsbox`.`address`.`userID`    AS `userID`
  from `smsbox`.`address`
  order by `smsbox`.`address`.`addressID` desc;

