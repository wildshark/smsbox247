create view get_notifications as
  select
    `smsbox`.`icon_label_type`.`type`                  AS `type`,
    `smsbox`.`icon_label_type`.`icon`                  AS `icon`,
    `smsbox`.`notifications`.`typeID`                  AS `typeID`,
    `smsbox`.`notifications`.`userID`                  AS `userID`,
    `smsbox`.`notifications`.`notificationsID`         AS `notificationsID`,
    `smsbox`.`notifications`.`statusID`                AS `statusID`,
    `smsbox`.`notifications`.`notifications`           AS `notifications`,
    `smsbox`.`notifications`.`note_date`               AS `note_date`,
    cast(`smsbox`.`notifications`.`note_date` as time) AS `ttime`,
    cast(`smsbox`.`notifications`.`note_date` as date) AS `ddate`
  from (`smsbox`.`icon_label_type`
    join `smsbox`.`notifications` on ((`smsbox`.`icon_label_type`.`typeID` = `smsbox`.`notifications`.`typeID`)))
  order by `smsbox`.`notifications`.`notificationsID` desc;

