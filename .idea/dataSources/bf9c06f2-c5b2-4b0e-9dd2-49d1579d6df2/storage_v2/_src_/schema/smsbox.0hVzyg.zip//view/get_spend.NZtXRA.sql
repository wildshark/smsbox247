create view get_spend as
  select
    count(`get_account`.`creditID`)                           AS `total_sms`,
    `get_account`.`userID`                                    AS `userID`,
    `get_account`.`spend`                                     AS `spend`,
    (count(`get_account`.`creditID`) * `get_account`.`spend`) AS `bill`,
    cast(`get_account`.`tranDate` as date)                    AS `ddate`
  from `smsbox`.`get_account`
  where (`get_account`.`paid` = 0)
  group by `get_account`.`userID`, `get_account`.`spend`;

