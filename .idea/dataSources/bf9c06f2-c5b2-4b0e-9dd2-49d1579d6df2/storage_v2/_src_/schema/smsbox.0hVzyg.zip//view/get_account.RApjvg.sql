create view get_account as
  select
    `smsbox`.`account`.`creditID`                            AS `creditID`,
    `smsbox`.`account`.`userID`                              AS `userID`,
    `smsbox`.`account`.`tranDate`                            AS `tranDate`,
    `smsbox`.`account`.`paid`                                AS `paid`,
    `smsbox`.`account`.`spend`                               AS `spend`,
    (`smsbox`.`account`.`paid` - `smsbox`.`account`.`spend`) AS `balance`
  from `smsbox`.`account`
  order by `smsbox`.`account`.`creditID` desc;

